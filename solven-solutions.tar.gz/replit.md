# Solven Solutions AS - Prosjektoversikt

## Prosjektinformasjon

**Type:** Next.js 14 nettside for AI-kundeservice selskap  
**Språk:** Norsk (bokmål) - Forberedt for engelsk i18n senere  
**Teknologi:** Next.js 14 + TypeScript + Tailwind CSS + Framer Motion  
**Opprettet:** 24. oktober 2025  

## Siste endringer

**25. oktober 2025:**
- Endret URL til www.solven.no
- "Book demo"-knapper scroller nå til kontaktskjemaet (bedre UX)
- Lagt til kopier e-post-funksjonalitet i kontakt-seksjonen
- Integrert Replit Mail for e-postutsendelse fra kontaktskjema
- E-post sendes til sales@solven.no med formatert HTML
- Endret case-stripe til å vise kun yrke (Restaurant, Rørlegger) uten fantasinavn
- Fikset hydration-feil ved å flytte Schema.org scripts til <body>

**24. oktober 2025:**
- Opprettet fullstendig Next.js 14 applikasjon
- Implementert alle hovedseksjoner med norsk innhold
- Konfigurert Google Analytics 4 integrasjon
- Lagt til mock AI chat-widget (aktiveres med env variabel)
- Implementert alle animasjoner og microinteraksjoner
- Satt opp API-route for kontaktskjema (/api/contact)
- Implementert SEO med meta tags, Open Graph, Schema.org

## Brukerpreferanser

**Design:**
- Mørk, eksklusiv palett (svart/grå/hvit) med subtil oransje accent (#ff6600)
- "Silent luxury" stil med glass-paneler og myke skygger
- Apple-inspirert scrollopplevelse med sticky seksjoner og parallax
- Konsekvent spacing, store overskrifter, mye luft

**Innhold:**
- Troverdig, trygg, moderne og resultatorientert tone
- Unngå hype - fokus på verdi og resultater
- Ferdig norsk innhold i alle seksjoner (presentasjonsklart)

## Prosjektarkitektur

### Struktur
```
app/
├── api/contact/route.ts    # Kontaktskjema API (sender e-post via Replit Mail)
├── layout.tsx              # Root layout med SEO og GA4
├── page.tsx                # Hovedside (single-page)
└── JsonLd.tsx              # Schema.org structured data

components/
├── Header.tsx              # Sticky nav med smooth scroll
├── Hero.tsx                # Parallax hero med KPI-counters
├── WhySolven.tsx           # 3 kolonner med features
├── Journey.tsx             # 4 sticky scrollytelling-paneler
├── Packages.tsx            # 3 priskort med disclaimer
├── CaseStripe.tsx          # 2 cases med før/etter KPI
├── TrustBadges.tsx         # Trust indicators
├── Security.tsx            # Sikkerhet og compliance
├── FAQ.tsx                 # Accordion med 8 spørsmål
├── Contact.tsx             # Kontaktskjema
├── Footer.tsx              # Footer med firmainformasjon
├── ChatWidget.tsx          # Mock AI chat (DEMO_WIDGET_ENABLED)
└── ExitIntentCTA.tsx       # Sticky footer CTA ved scroll

lib/
├── config.ts               # Sentralisert konfigurasjon
└── replitmail.ts           # E-post via Replit Mail integrasjon
```

### Miljøvariabler
- `NEXT_PUBLIC_GA_ID`: Google Analytics 4 ID
- `DEMO_WIDGET_ENABLED`: Aktiverer AI chat-widget (true/false)
- `SESSION_SECRET`: Allerede tilgjengelig i miljøet

### Features
✅ Sticky navigasjon med smooth scroll til seksjoner  
✅ Parallax-effekt i hero  
✅ Animerte KPI-kort som teller opp ved in-view  
✅ 4 sticky leveransereise-paneler med fade/translate/scale  
✅ 3 pakker med tydelig pris-disclaimer  
✅ FAQ accordion med smooth animasjoner  
✅ Kontaktskjema med validering + API-route  
✅ Mock AI chat-widget (aktiveres med env var)  
✅ Exit-intent sticky CTA ved scroll >50%  
✅ Case-stripe med realistiske før/etter tall  
✅ Trust badges for tillit  
✅ Google Analytics 4 med Do Not Track respekt  
✅ SEO-optimalisert (meta, OG, Schema.org)  
✅ Responsivt design (mobile-first)  

### Deployment til Vercel
Se **DEPLOY_TO_VERCEL.md** for fullstendige instruksjoner.

**Rask guide:**
1. Last ned alle filene fra Replit
2. Gå til https://vercel.com
3. Klikk "Add New Project" → Import fra GitHub
4. Deploy (tar ~2 minutter)
5. Legg til custom domain www.solven.no i Vercel Dashboard

### Neste fase
- [ ] Cookie-banner for GDPR
- [ ] Juridiske undersider (Personvern, Vilkår, DPA)
- [ ] Bytt placeholder-cases med ekte kundedata
- [ ] i18n for engelsk oversettelse

## Notater
- Alle priser er eksempler - disclaimer vises tydelig
- AI chat-widget er mock (ingen backend)
- Kontaktskjema sender faktisk e-post til sales@solven.no via Replit Mail
- "Book demo"-knapper scroller smooth til kontaktskjemaet
- Kopier e-post-funksjonalitet for brukere uten e-postklient
- Ferdig norsk tekst i alle seksjoner
- Klar for presentasjon, salg-demo og publishing
